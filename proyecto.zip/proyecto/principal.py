
from colorama import Fore, Style, init
from productos import *
from productos_db import *

init(autoreset=True)

#funciones de saludo al usuario#

def saludar_usuario():
    print(Fore.CYAN + "=" * 40)
    print("👋 ¡Bienvenido a Nuestra Tienda Online!")
    print(Fore.CYAN + "=" * 40)

    nombre = validar_tex(input("Ingrese su nombre: ").strip())
    apellido = validar_tex(input("Ingrese su apellido: ").strip())

    print(Fore.GREEN + f"\nHola {nombre} {apellido} 😊 ¡Bienvenida!\n")
    return nombre, apellido

#funciones de despedida#
def despedir_usuario(nombre, apellido):
    print(Fore.YELLOW + "=" * 50)
    print(f"👋 Gracias por usar nuestro sistema, {nombre} {apellido}.")
    print(Fore.YELLOW +  "=" * 50)





def menu():
    print(Fore.BLUE + "=" * 40)
    print("        🏪  Menú de Tienda")
    print(Fore.BLUE +"=" * 40)
    print("1. 🛒 Agregar un nuevo producto")
    print("2. 📋 Ver productos")
    print("3. 🔍 Buscar un producto")
    print("4. ⚒️ Actualizar producto")
    print("5. ❌ Eliminar producto")
    print("6. ⚠ Reporte Bajo Stock")
    print("7. 🚨 Salir del sistema")
    print(Fore.BLUE +"=" * 40)




def principal():
    conexion = conectar()
    crear_tabla(conexion)

    nombre, apellido = saludar_usuario()

    while True:
        menu()
        opcion = input("Elegí una opción: ").strip()

        if opcion == "1":
            agregar_producto(conexion)
        elif opcion == "2":
            ver_productos(conexion)
        elif opcion == "3":
            buscar_producto(conexion)
        elif opcion == "4":
            actualizar_stock_producto(conexion)
        elif opcion == "5":
            eliminar_producto_por_id(conexion)
        elif opcion == "6":
            reporte_bajo_stock(conexion)
        elif opcion == "7":
            despedir_usuario(nombre, apellido)
            break
        else:
            print(Fore.RED + "❌ Opción inválida. Intentá de nuevo.\n")




if __name__ == '__main__':
    principal()
