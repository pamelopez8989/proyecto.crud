Este proyecto se basa en la creación de un sistema de manejo de productos, simula una tienda.
Para su ejecución se tuvo en cuenta:
-Módulos
*Principal, donde se ejecuta el programa Principal
* Productos donde se encuentran las funciones de validación del menú
* Productos_db donde se encuentran las funciones para ejecutar las consultas de la base de datos


Para la codificación de este programa se utilizo:
Lenguaje: python
Editor de Código: visual Studio code

 
Base de datos : SQLite 
Me permitió realizar un CRUD completo,
Reporte de bajo stock


En el Menú se utilizo la librería: colorama

 


Creador Pamela Lopez 
versión 1 08/12/2025
