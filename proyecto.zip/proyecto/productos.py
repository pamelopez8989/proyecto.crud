
from productos_db import *

# FUNCIONES DE VALIDACION MENU #
def validar_num(valor):
    while valor.strip() == "" or not valor.isdigit():
        print("Debe ingresar un número y no puede estar vacío.")
        valor = input("Reingrese: ").strip()
    return int(valor)


def validar_float(valor):
    while True:
        if valor.strip() == "":
            valor = input("El campo no puede estar vacío. Reingrese: ").strip()
            continue

        try:
            return float(valor)
        except:
            valor = input("Ingrese un valor numérico válido: ").strip()


def validar_tex(valor):
    while valor.strip() == "" or not valor.replace(" ", "").isalpha():
        print("Debe ingresar SOLO texto y no puede estar vacío.")
        valor = input("Reingrese: ").strip()
    return valor

def validar_descri(valor):

    valor = valor.strip()
    
    while valor == "":
        print("La descripción no puede estar vacía.")
        print("No puede contener solo espacios.")
    
        valor = input("Reingrese la descripción: ").strip()
    
    return valor




# FUNCIONES DEL CRUD #

def agregar_producto(conexion):
    print("\n--- ALTA PRODUCTO ---")
    nombre = validar_tex(input("Nombre: "))
    descripcion = validar_descri(input("Descripción: "))
    cantidad = validar_num(input("Cantidad: "))
    precio = validar_float(input("Precio: "))
    categoria = validar_tex(input("Categoría: "))

    inser_producto(conexion, nombre, descripcion, cantidad, precio, categoria)


def ver_productos(conexion):
    productos = obtener_producto(conexion)
    if not productos:
        print("No hay productos cargados.")
        return

    print("\n--- LISTADO ---")
    for p in productos:
        print(f"ID:{p[0]} | {p[1]} | Cant:{p[3]} | ${p[4]} | {p[5]}")


def buscar_producto(conexion):
    id_buscar = validar_num(input("ID a buscar: "))
    producto = buscar_porid(conexion, id_buscar)

    if producto:
        print(f"✔ Encontrado: {producto}")
    else:
        print("❌ No existe un producto con ese ID.")


def actualizar_stock_producto(conexion):
    id_prod = validar_num(input("ID a actualizar: "))
    nuevo_stock = validar_num(input("Nuevo stock: "))
    actualizar_stock(conexion, id_prod, nuevo_stock)


def eliminar_producto_por_id(conexion):
    id_prod = validar_num(input("ID a eliminar: "))
    eliminar_producto(conexion, id_prod)


def reporte_bajo_stock(conexion):
    limite = validar_num(input("Mostrar productos con stock ≤: "))
    productos = obtener_bajo_stock(conexion, limite)

    if not productos:
        print("No hay productos bajo ese límite.")
        return

    print("\n--- PRODUCTOS BAJO STOCK ---")
    for p in productos:
        print(f"ID:{p[0]} | {p[1]} | Cant:{p[3]} | Cat:{p[5]}")
